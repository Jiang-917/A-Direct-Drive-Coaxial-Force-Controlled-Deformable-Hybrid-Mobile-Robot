/**
  ****************************(C) COPYRIGHT 2024 DJI****************************
  * @file       Buzzer.c/h
  * @brief      ������ʵ�ֺ���
  * @note       
  * @history
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2016 DJI****************************
  */
#ifndef BUZZER_H
#define BUZZER_H


/**
  * @brief          ����������
  * @param[out]     none
  * @retval         none
  */
void Buzzer_Start(void);

/**
  * @brief          �رշ�����
  * @param[out]     none
  * @retval         none
  */
void Buzzer_Stop(void);

#endif

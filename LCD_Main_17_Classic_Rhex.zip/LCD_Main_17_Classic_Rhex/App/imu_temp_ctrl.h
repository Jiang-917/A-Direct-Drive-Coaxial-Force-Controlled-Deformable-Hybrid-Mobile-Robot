#ifndef IMU_TEMP_CTRL_H
#define IMU_TEMP_CTRL_H

void INS_Init(void);

void INS_Task(void);  //1khz


#endif // IMU_TEMP_CTRL_H

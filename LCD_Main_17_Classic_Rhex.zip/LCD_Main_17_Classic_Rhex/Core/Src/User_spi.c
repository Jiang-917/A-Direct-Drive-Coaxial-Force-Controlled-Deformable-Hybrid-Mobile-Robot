#include "User_spi.h"
#include "math.h"
#include "BMI088driver.h"


//�洢���������ݵ�����
uint8_t gyro_dma_rx_buf[SPI_DMA_GYRO_LENGHT];
uint8_t gyro_dma_tx_buf[SPI_DMA_GYRO_LENGHT] = {0x82,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

uint8_t accel_dma_rx_buf[SPI_DMA_ACCEL_LENGHT];
uint8_t accel_dma_tx_buf[SPI_DMA_ACCEL_LENGHT] = {0x92,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

uint8_t accel_temp_dma_rx_buf[SPI_DMA_ACCEL_TEMP_LENGHT];
uint8_t accel_temp_dma_tx_buf[SPI_DMA_ACCEL_TEMP_LENGHT] = {0xA2,0xFF,0xFF,0xFF};

volatile uint8_t gyro_update_flag = 0;
volatile uint8_t accel_update_flag = 0;
volatile uint8_t accel_temp_update_flag = 0;
volatile uint8_t mag_update_flag = 0;
volatile uint8_t imu_start_dma_flag = 0;


extern SPI_HandleTypeDef hspi2;
extern DMA_HandleTypeDef hdma_spi2_rx;
extern DMA_HandleTypeDef hdma_spi2_tx;


bmi088_real_data_t bmi088_real_data;
ist8310_real_data_t ist8310_real_data;

float INS_quat[4] = {0.0f, 0.0f, 0.0f, 0.0f};
float INS_angle[3] = {0.0f, 0.0f, 0.0f};      //euler angle, unit rad.ŷ���� ��λ rad



void SPI2_DMA_init(uint32_t tx_buf, uint32_t rx_buf, uint16_t num)
{
    SET_BIT(hspi2.Instance->CR2, SPI_CR2_TXDMAEN);
    SET_BIT(hspi2.Instance->CR2, SPI_CR2_RXDMAEN);

    __HAL_SPI_ENABLE(&hspi2);


    //disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(&hdma_spi2_rx);
    
    while(hdma_spi2_rx.Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(&hdma_spi2_rx);
    }

    __HAL_DMA_CLEAR_FLAG(&hdma_spi2_rx, DMA_LISR_TCIF2);

    hdma_spi2_rx.Instance->PAR = (uint32_t) & (SPI2->DR);
    //memory buffer 1
    //�ڴ滺����1
    hdma_spi2_rx.Instance->M0AR = (uint32_t)(rx_buf);
    //data length
    //���ݳ���
    __HAL_DMA_SET_COUNTER(&hdma_spi2_rx, num);

    __HAL_DMA_ENABLE_IT(&hdma_spi2_rx, DMA_IT_TC);


    //disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(&hdma_spi2_tx);
    
    while(hdma_spi2_tx.Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(&hdma_spi2_tx);
    }


    __HAL_DMA_CLEAR_FLAG(&hdma_spi2_tx, DMA_LISR_TCIF3);

    hdma_spi2_tx.Instance->PAR = (uint32_t) & (SPI2->DR);
    //memory buffer 1
    //�ڴ滺����1
    hdma_spi2_tx.Instance->M0AR = (uint32_t)(tx_buf);
    //data length
    //���ݳ���
    __HAL_DMA_SET_COUNTER(&hdma_spi2_tx, num);


}

void SPI2_DMA_enable(uint32_t tx_buf, uint32_t rx_buf, uint16_t ndtr)
{
    //disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(&hdma_spi2_rx);
    __HAL_DMA_DISABLE(&hdma_spi2_tx);
    while(hdma_spi2_rx.Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(&hdma_spi2_rx);
    }
    while(hdma_spi2_tx.Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(&hdma_spi2_tx);
    }
    //clear flag
    //�����־λ
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmarx, __HAL_DMA_GET_TC_FLAG_INDEX(hspi2.hdmarx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmarx, __HAL_DMA_GET_HT_FLAG_INDEX(hspi2.hdmarx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmarx, __HAL_DMA_GET_TE_FLAG_INDEX(hspi2.hdmarx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmarx, __HAL_DMA_GET_DME_FLAG_INDEX(hspi2.hdmarx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmarx, __HAL_DMA_GET_FE_FLAG_INDEX(hspi2.hdmarx));

    __HAL_DMA_CLEAR_FLAG (hspi2.hdmatx, __HAL_DMA_GET_TC_FLAG_INDEX(hspi2.hdmatx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmatx, __HAL_DMA_GET_HT_FLAG_INDEX(hspi2.hdmatx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmatx, __HAL_DMA_GET_TE_FLAG_INDEX(hspi2.hdmatx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmatx, __HAL_DMA_GET_DME_FLAG_INDEX(hspi2.hdmatx));
    __HAL_DMA_CLEAR_FLAG (hspi2.hdmatx, __HAL_DMA_GET_FE_FLAG_INDEX(hspi2.hdmatx));
    //set memory address
    //�������ݵ�ַ
    hdma_spi2_rx.Instance->M0AR = rx_buf;
    hdma_spi2_tx.Instance->M0AR = tx_buf;
    //set data length
    //�������ݳ���
    __HAL_DMA_SET_COUNTER(&hdma_spi2_rx, ndtr);
    __HAL_DMA_SET_COUNTER(&hdma_spi2_tx, ndtr);
    //enable DMA
    //ʹ��DMA
    __HAL_DMA_ENABLE(&hdma_spi2_rx);
    __HAL_DMA_ENABLE(&hdma_spi2_tx);
}




///**
//  * @brief          open the SPI DMA accord to the value of imu_update_flag
//  * @param[in]      none
//  * @retval         none
//  */
///**
//  * @brief          ����imu_update_flag��ֵ����SPI DMA
//  * @param[in]      temp:bmi088���¶�
//  * @retval         none
//  */
//void imu_cmd_spi_dma(void)
//{	
//				
//				//���⣺�Ҳ���flag ��ʲôʱ�����DR_SHFITS
//        //���������ǵ�DMA����
//				//�������ƣ�flag �� SHIFTSλ��1 ��  DMA����û���ڿ���״̬ �Ҽ��ٶȺ��¶ȶ�û��ռ��spi�����������������ĳһʱ��������״̬��Ϊ1ʱ��ô��
//        if( (gyro_update_flag & (1 << IMU_DR_SHFITS) ) && !(hspi2.hdmatx->Instance->CR & DMA_SxCR_EN) 
//        && !(accel_update_flag & (1 << IMU_SPI_SHFITS)) && !(accel_temp_update_flag & (1 << IMU_SPI_SHFITS)))
//        {
//            gyro_update_flag &= ~(1 << IMU_DR_SHFITS);//ȥ��DR��SHFITS
//            gyro_update_flag |= (1 << IMU_SPI_SHFITS);//����SPI��SHFITS

//            HAL_GPIO_WritePin(SPI2_Gyro_CS_GPIO_Port, SPI2_Gyro_CS_Pin, GPIO_PIN_RESET);//����GYRO����
//            SPI2_DMA_enable((uint32_t)gyro_dma_tx_buf, (uint32_t)gyro_dma_rx_buf, SPI_DMA_GYRO_LENGHT);//ʹ��spiDMA��
//            return;
//        }
//        //�������ٶȼƵ�DMA����
//        if((accel_update_flag & (1 << IMU_DR_SHFITS)) && !(hspi2.hdmatx->Instance->CR & DMA_SxCR_EN) && !(hspi2.hdmarx->Instance->CR & DMA_SxCR_EN)
//        && !(gyro_update_flag & (1 << IMU_SPI_SHFITS)) && !(accel_temp_update_flag & (1 << IMU_SPI_SHFITS)))
//        {
//            accel_update_flag &= ~(1 << IMU_DR_SHFITS);
//            accel_update_flag |= (1 << IMU_SPI_SHFITS);

//            HAL_GPIO_WritePin(SPI2_Accel_CS_GPIO_Port, SPI2_Accel_CS_Pin, GPIO_PIN_RESET);
//            SPI2_DMA_enable((uint32_t)accel_dma_tx_buf, (uint32_t)accel_dma_rx_buf, SPI_DMA_ACCEL_LENGHT);
//            return;
//        }
//        


//				//�����¶ȼ�DMA����
//        if((accel_temp_update_flag & (1 << IMU_DR_SHFITS)) && !(hspi2.hdmatx->Instance->CR & DMA_SxCR_EN) && !(hspi2.hdmarx->Instance->CR & DMA_SxCR_EN)
//        && !(gyro_update_flag & (1 << IMU_SPI_SHFITS)) && !(accel_update_flag & (1 << IMU_SPI_SHFITS)))
//        {
//            accel_temp_update_flag &= ~(1 << IMU_DR_SHFITS);
//            accel_temp_update_flag |= (1 << IMU_SPI_SHFITS);

//            HAL_GPIO_WritePin(SPI2_Accel_CS_GPIO_Port, SPI2_Accel_CS_Pin, GPIO_PIN_RESET);
//            SPI2_DMA_enable((uint32_t)accel_temp_dma_tx_buf, (uint32_t)accel_temp_dma_rx_buf, SPI_DMA_ACCEL_TEMP_LENGHT);
//            return;
//        }
//}


////spi�����Ǻ���

////ARHS�㷨��ʼ��
//void AHRS_init(float quat[4], float accel[3])
//{
//    quat[0] = 1.0f;
//    quat[1] = 0.0f;
//    quat[2] = 0.0f;
//    quat[3] = 0.0f;

//}

//////ͨ�������Ƿ������������������Ƕȣ�ʹ�õ��㷨ΪARHS�㷨
////void AHRS_update(float quat[4], float time, float gyro[3], float accel[3], float mag[3])
////{
////    MahonyAHRSupdate(quat, gyro[0], gyro[1], gyro[2], accel[0], accel[1], accel[2], mag[0], mag[1], mag[2]);
////}

////ͨ������õ������Ƕ�
//void get_angle(float q[4], float *yaw, float *pitch, float *roll)
//{
//    *yaw = atan2f(2.0f*(q[0]*q[3]+q[1]*q[2]), 2.0f*(q[0]*q[0]+q[1]*q[1])-1.0f);
//    *pitch = asinf(-2.0f*(q[1]*q[3]-q[0]*q[2]));
//    *roll = atan2f(2.0f*(q[0]*q[1]+q[2]*q[3]),2.0f*(q[0]*q[0]+q[3]*q[3])-1.0f);

////		static uint8_t temp[50] = {0};
////		sprintf((char *)temp, "yaw:%f	pitch:%f	roll:%f\r\n", (*yaw)*57.32, (*pitch)*57.32, (*roll)*57.32);
////		HAL_UART_Transmit_DMA(&huart1, temp, sizeof(temp));
//}

////��freertos��ѭ�������е�������
//void BMI088_Task_Do(void)
//{

//  //wait spi DMA tansmit done
//        //�ȴ�SPI DMA����
//				//�˺������ڻ�ȡ��ǰ�����ֵ֪ͨ,�ж����ֵ֪ͨ�Ƿ�ΪTrue
//				//ͨ��GPIO�ⲿ�ж��������Ƿ���������
////        while (ulTaskNotifyTake(pdTRUE, portMAX_DELAY) != pdPASS)
////        {
////        }

//		//�����ǿ��Ʋ���
//   if(gyro_update_flag & (1 << IMU_UPDATE_SHFITS))
//    {
//       gyro_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
//       BMI088_gyro_read_over(gyro_dma_rx_buf + BMI088_GYRO_RX_BUF_DATA_OFFSET, bmi088_real_data.gyro);
//    }
//		//���ٶȿ��Ʋ���
//    if(accel_update_flag & (1 << IMU_UPDATE_SHFITS))
//    {
//        accel_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
//        BMI088_accel_read_over(accel_dma_rx_buf + BMI088_ACCEL_RX_BUF_DATA_OFFSET, bmi088_real_data.accel, &bmi088_real_data.time);
//    }
////		//�¶ȿ��Ʋ��֣���ʱ����Ҫ��
////    if(accel_temp_update_flag & (1 << IMU_UPDATE_SHFITS))
////    {
////        accel_temp_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
////        BMI088_temperature_read_over(accel_temp_dma_rx_buf + BMI088_ACCEL_RX_BUF_DATA_OFFSET, &bmi088_real_data.temp);
////        imu_temp_control(bmi088_real_data.temp);
////    }

//		//��AHRS�㷨����BMI088�õ�������
//    AHRS_update(INS_quat, 0.001f, bmi088_real_data.gyro, bmi088_real_data.accel, ist8310_real_data.mag);
//		//���������������Ƕ�
//    get_angle(INS_quat, INS_angle + INS_YAW_ADDRESS_OFFSET, INS_angle + INS_PITCH_ADDRESS_OFFSET, INS_angle + INS_ROLL_ADDRESS_OFFSET);

//}



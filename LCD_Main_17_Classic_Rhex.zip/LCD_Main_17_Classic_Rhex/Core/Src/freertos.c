/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * File Name          : freertos.c
 * Description        : Code for freertos applications
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2023 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "queue.h"
#include "stm32f4xx_hal.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>

#include "BMI088driver.h"
#include "Buzzer.h"
#include "can.h"
#include "Control_Matrix.h"
#include "Curve_Calculate.h"
#include "DrEmpower_can.h"
#include "imu_temp_control_task.h"
#include "jaccobi_3conditions.h"
#include "LGT.h"
#include "pid.h"
#include "usbd_cdc_if.h"
#include "User_Delay.h"
#include "User_Dwt.h"
#include "User_spi.h"
#include "User_Usart.h"
#include "vofa.h"
#include "tim.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PI 3.14159265357
#define MOTOR_NUM 16

#define Walk_Len 0.08  // ���г���
#define Step_h -0.135  // �˶�ʱ�Ȳ�λ��
#define Step_H -0.0825 // ̧��ʱ�Ȳ�λ��
#define Times 30	   // �켣�Ĳ�ִ���
#define Dly 25

Pth_struct Pth1, Pth2, Pth3; // ��������ṹ��

extern float motor_state[MOTOR_NUM][5];
extern uint8_t Read_Success_flag1357;
// ����ṹ������
extern LGT_Motor_Handler LGT_Motor_Group[7];
extern uint8_t LGT_rx_buffer[8];
// ���ݻ�ȡ�ṹ������(������)
extern struct servo_state Locat_DrLan1;
extern struct servo_state Locat_DrLan2;
extern struct servo_state Locat_DrLan3;
extern struct servo_state Locat_DrLan4;
extern struct servo_state Locat_DrLan5;
// �������
float ST_Unit = -4.5;
unsigned int OLED_Num = 0;
// ����sin �˶�����
extern Motor_Matrix_Unit Motor_Matrix_Unit_Group[Test_Len];
// LGT�����������
extern float **Calculate_Group_LGT_Position; // ���λ������
extern float **Calculate_Group_LGT_Velocity; // ����ٶ�����
// ���� is_Moving ����
extern uint8_t is_Moving_Goup[4];
// ���ڲ��Զ���
// �Ӵ��ڶ�����ȡ�������ݵĻ�����
QUEUE_DATA_T queue_buf_temp[RX_LENGTH];
Rx_Count_Union queue_count_temp;
uint8_t data_can[8] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07};
extern int8_t READ_FLAG;
// ��Ȼ�����������
uint8_t Id_Test[5] = {1, 2, 3, 4, 5};
float Position_Test1[5] = {10, 10, 20, 20, 20};
float Position_Test2[5] = {30, 30, 50, 50, 50};
float Position_Test3[5] = {100, 100, 130, 130, 130};
float Position_Test4[5] = {0, 0, 0, 0, 0};
int LGT_Matrix_Count = 0;
// �пյ����������
float LGT_Speed[1] = {20};
float LGT_Target_Pos1[1] = {0};
float LGT_Target_Pos2[1] = {8};
// CAN2 ��ӡλ
extern uint8_t Printf_CAN2_FLAG;
uint8_t Debug_Flag = 1;
extern uint8_t Dynamixel_isControl; // �����Ŀ��Ʊ�־λ������λ��1ʱ�����ƶ��
uint8_t Huaner_Sent[6];
// �����õ��������ǶȵĽṹ��
// Th_Stru Th_Stru_Test1;
// λ��Position
unsigned char Position_1 = 0;
int flag = 1;
int flag_LGT = 1;
// ����5������ֱ�Ŀ�������
// Motor_Matrix_Unit* DrLan_Control_Matrix[5] = {Motor_Matrix_Unit_Group , Motor_Matrix_Unit_Group , Motor_Matrix_Unit_Group , Motor_Matrix_Unit_Group ,Motor_Matrix_Unit_Group};
extern uint32_t Frequency_Os; // ϵͳʱ��Ƶ��
uint16_t Os_Systick;		  // ϵͳʱ�Ӽ���ֵ
uint16_t Os_Systick_LGT;	  // �пյ������ʹ�õ�ϵͳʱ�Ӽ���ֵ
uint16_t Os_Sys_Output;		  // ϵͳʱ�����ֵ
uint16_t OS_Sys_Output_LGT;	  // �пյ������ʹ�õ�ϵͳʱ�����ֵ
extern float DPoint_th_Group[3000][2];
// �пյ���ṹ����
extern LGT_Motor_Handler Motor_Test;
int flag_test_2 = 749;
// ��ɫ�������
uint16_t pwmVal = 0; // PWMռ�ձ�
uint8_t pwmdir = 1;

extern float roll_mahony, pitch_mahony, yaw_mahony;
extern float roll, pitch, yaw; // ŷ����
// extern fp32 gyro[3], accel[3], temp;
int16_t gyro1[3];
extern uint32_t temp_temperature;
// spi�������
extern SPI_HandleTypeDef hspi2;
extern DMA_HandleTypeDef hdma_spi2_rx;
extern DMA_HandleTypeDef hdma_spi2_tx;

// �����Ǳ���
extern float roll, pitch, yaw;

// ������ݶ���
QueueHandle_t uartQueue;
uint8_t id;
float Dr_pos, Dr_vel, Dr_trf, LGT_pos, LGT_vel, LGT_trf;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for ElectTask_DrLan */
osThreadId_t ElectTask_DrLanHandle;
const osThreadAttr_t ElectTask_DrLan_attributes = {
	.name = "ElectTask_DrLan",
	.stack_size = 512 * 4,
	.priority = (osPriority_t)osPriorityNormal1,
};
/* Definitions for BMI088_INS */
osThreadId_t BMI088_INSHandle;
const osThreadAttr_t BMI088_INS_attributes = {
	.name = "BMI088_INS",
	.stack_size = 256 * 4,
	.priority = (osPriority_t)osPriorityNormal7,
};
/* Definitions for USB_Debug */
osThreadId_t USB_DebugHandle;
const osThreadAttr_t USB_Debug_attributes = {
	.name = "USB_Debug",
	.stack_size = 256 * 4,
	.priority = (osPriority_t)osPriorityNormal2,
};
/* Definitions for Empty_Task */
osThreadId_t Empty_TaskHandle;
const osThreadAttr_t Empty_Task_attributes = {
	.name = "Empty_Task",
	.stack_size = 512 * 4,
	.priority = (osPriority_t)osPriorityNormal4,
};
/* Definitions for Ben_Leg */
osThreadId_t Ben_LegHandle;
const osThreadAttr_t Ben_Leg_attributes = {
	.name = "Ben_Leg",
	.stack_size = 512 * 4,
	.priority = (osPriority_t)osPriorityNormal5,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/*--------------------------*/

/* USER CODE END FunctionPrototypes */

void DrLanTask(void *argument);
void BMI088_INSTask(void *argument);
void DebugTask(void *argument);
void Empty_Task04(void *argument);
void Ben_Leg_task(void *argument);

extern void MX_USB_DEVICE_Init(void);
void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
 * @brief  FreeRTOS initialization
 * @param  None
 * @retval None
 */
void MX_FREERTOS_Init(void)
{
	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
	/* USER CODE END RTOS_MUTEX */

	/* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
	/* USER CODE END RTOS_SEMAPHORES */

	/* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
	/* USER CODE END RTOS_TIMERS */

	/* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
	uartQueue = xQueueCreate(10, sizeof(uint8_t[30]));
	/* USER CODE END RTOS_QUEUES */

	/* Create the thread(s) */
	/* creation of ElectTask_DrLan */
	ElectTask_DrLanHandle = osThreadNew(DrLanTask, NULL, &ElectTask_DrLan_attributes);

	/* creation of BMI088_INS */
	BMI088_INSHandle = osThreadNew(BMI088_INSTask, NULL, &BMI088_INS_attributes);

	/* creation of USB_Debug */
	USB_DebugHandle = osThreadNew(DebugTask, NULL, &USB_Debug_attributes);

	/* creation of Empty_Task */
	Empty_TaskHandle = osThreadNew(Empty_Task04, NULL, &Empty_Task_attributes);

	/* creation of Ben_Leg */
	Ben_LegHandle = osThreadNew(Ben_Leg_task, NULL, &Ben_Leg_attributes);

	/* USER CODE BEGIN RTOS_THREADS */
	/* add threads, ... */
	/* USER CODE END RTOS_THREADS */

	/* USER CODE BEGIN RTOS_EVENTS */
	/* add events, ... */
	/* USER CODE END RTOS_EVENTS */
}

/* USER CODE BEGIN Header_DrLanTask */
/**
 * @brief  Function implementing the ElectTask_DrLan thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_DrLanTask */
void DrLanTask(void *argument)
{
	/*rhex�迹ģʽ*/
	/* USER CODE BEGIN DrLanTask */
	int num = 1;
	float DrPara;
	float i = 30;
	float j = 0;
	float a = 0;
	float b = (PI / 6.0);
	float c = 0;
	set_zero_position(4);
	set_zero_position(5);
	set_zero_position(6);
	LGT_Motor_Enable(LGT_Motor_Group[4]);
	LGT_Motor_Enable(LGT_Motor_Group[5]);
	LGT_Motor_Enable(LGT_Motor_Group[6]);
	impedance_control(4, i, 0, 1, 5.0, 4.0);
	osDelay(1);
	impedance_control(5, j, 0, 1, 5.0, 0.8);
	osDelay(1);
	impedance_control(6, i, 0, 1, 5.0, 0.8);
	LGT_Motor_Group[4].Target_Angle = a;
	LGT_Motor_Group[5].Target_Angle = b;
	LGT_Motor_Group[6].Target_Angle = c;
	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[4]);
	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[5]);
	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[6]);
	osDelay(5000);
	// /* Infinite loop */
	for (;;)
	{
		if (num > 0 && num <= Times)
		{
			i += 150 / Times;
			j += 30 / Times;
			a = a - PI / 177 * 150 / Times;
			b = b - PI / 178 * 30 / Times;
			c = c - PI / 177 * 150 / Times;
			LGT_Motor_Group[4].Target_Angle = a;
			LGT_Motor_Group[5].Target_Angle = b;
			LGT_Motor_Group[6].Target_Angle = c;
			impedance_control(4, i, 0, 1, 5.0, 4.0);
			LGT_impedance_Control(LGT_Motor_Group[4]);
			osDelay(1);
			impedance_control(5, j, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[5]);
			osDelay(1);
			impedance_control(6, i, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[6]);
			num++;
			osDelay(20);
		}
		else if (num > Times && num <= Times * 2)
		{
			i += 150 / Times;
			j += 30 / Times;
			a = a - PI / 177 * 150 / Times;
			b = b - PI / 178 * 30 / Times;
			c = c - PI / 177 * 150 / Times;
			LGT_Motor_Group[4].Target_Angle = a;
			LGT_Motor_Group[5].Target_Angle = b;
			LGT_Motor_Group[6].Target_Angle = c;
			impedance_control(4, i, 0, 1, 5.0, 4.0);
			LGT_impedance_Control(LGT_Motor_Group[4]);
			osDelay(1);
			impedance_control(5, j, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[5]);
			osDelay(1);
			impedance_control(6, i, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[6]);
			num++;
			osDelay(20);
		}
		else if (num > Times * 2 && num <= Times * 3)
		{
			i += 30 / Times;
			j += 150 / Times;
			a = a - PI / 177 * 30 / Times;
			b = b - PI / 178 * 150 / Times;
			c = c - PI / 177 * 30 / Times;
			LGT_Motor_Group[4].Target_Angle = a;
			LGT_Motor_Group[5].Target_Angle = b;
			LGT_Motor_Group[6].Target_Angle = c;
			impedance_control(4, i, 0, 1, 5.0, 4.0);
			LGT_impedance_Control(LGT_Motor_Group[4]);
			osDelay(1);
			impedance_control(5, j, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[5]);
			osDelay(1);
			impedance_control(6, i, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[6]);
			num++;
			osDelay(20);
		}
		else if (num > Times * 3 && num <= Times * 4)
		{
			i += 30 / Times;
			j += 150 / Times;
			a = a - PI / 177 * 30 / Times;
			b = b - PI / 178 * 150 / Times;
			c = c - PI / 177 * 30 / Times;
			LGT_Motor_Group[4].Target_Angle = a;
			LGT_Motor_Group[5].Target_Angle = b;
			LGT_Motor_Group[6].Target_Angle = c;
			impedance_control(4, i, 0, 1, 5.0, 4.0);
			LGT_impedance_Control(LGT_Motor_Group[4]);
			osDelay(1);
			impedance_control(5, j, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[5]);
			osDelay(1);
			impedance_control(6, i, 0, 1, 5.0, 0.8);
			LGT_impedance_Control(LGT_Motor_Group[6]);
			num++;
			osDelay(20);
		}
		else if (num > Times * 4)
		{
			num = 1;
		}
		osDelay(2);
		unpackCanInfoFromMotor(LGT_rx_buffer, LGT_Motor_Group);
		DrPara = read_property(4, 38009, 0);
		User_UART_STLINK_printf("%f, %f\n", DrPara, LGT_Motor_Group[4].Output_Torque);
	}
	

	/*leg�迹ģʽ */
	int i = 0;
	float k1p, k1d;
	k1p = 5.0;
	k1d = 0.8;

	set_zero_position(1);
	set_zero_position(2);
	set_zero_position(3);
	LGT_Motor_Enable(LGT_Motor_Group[1]);
	LGT_Motor_Enable(LGT_Motor_Group[2]);
	LGT_Motor_Enable(LGT_Motor_Group[3]);
	position_angle(-Walk_Len, Step_h, &Pth1); // C�㴥��
	position_angle(Walk_Len, Step_m, &Pth2);  // D�㴥��
	position_angle(0, Step_H, &Pth3);		  // ��̧��
	position_angle(0, Step_M, &Pth4);		  // �м�̬

	double th1, th2, th3, th4;

	th1 = Pth1.Th2;
	th2 = th1;
	th3 = Pth1.Th1;
	th4 = th3;

	LGT_Motor_Group[1].Target_Angle = th1;
	LGT_Motor_Group[2].Target_Angle = th1;
	LGT_Motor_Group[3].Target_Angle = th1;

	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[1]);
	impedance_control(1, th3, 0, 0, k1p, k1d);
	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[2]);
	impedance_control(2, th3, 0, 0, k1p, k1d);
	osDelay(1);
	LGT_impedance_Control(LGT_Motor_Group[3]);
	impedance_control(3, th3, 0, 0, k1p, k1d);
	vTaskDelay(50);

	for (;;)
	{
		if (i <= Times)
		{
			th1 += (Pth3.Th2 - Pth1.Th2) / Times;
			th2 += (Pth4.Th2 - Pth1.Th2) / Times;
			th3 += (Pth3.Th1 - Pth1.Th1) / Times;
			th4 += (Pth4.Th1 - Pth1.Th1) / Times;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times < i && i <= Times * 3 / 2)
		{
			th1 += (Pth1.Th2 - Pth3.Th2) / Times * 2;
			th2 += (Pth2.Th2 - Pth4.Th2) / Times;
			th3 += (Pth1.Th1 - Pth3.Th1) / Times * 2;
			th4 += (Pth2.Th1 - Pth4.Th1) / Times;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times * 3 / 2 < i && i <= Times * 2)
		{
			th1 += (Pth4.Th2 - Pth1.Th2) / Times;
			th2 += (Pth2.Th2 - Pth4.Th2) / Times;
			th3 += (Pth4.Th1 - Pth1.Th1) / Times;
			th4 += (Pth2.Th1 - Pth4.Th1) / Times;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times * 2 < i && i <= Times * 5 / 2)
		{
			th1 += (Pth4.Th2 - Pth1.Th2) / Times;
			th2 += (Pth3.Th2 - Pth2.Th2) / Times * 2;
			th3 += (Pth4.Th1 - Pth1.Th1) / Times;
			th4 += (Pth3.Th1 - Pth2.Th1) / Times * 2;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times * 5 / 2 < i && i <= Times * 3)
		{
			th1 += (Pth2.Th2 - Pth4.Th2) / Times;
			th2 += (Pth1.Th2 - Pth3.Th2) / Times * 2;
			th3 += (Pth2.Th1 - Pth4.Th1) / Times;
			th4 += (Pth1.Th1 - Pth3.Th1) / Times * 2;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times * 3 < i && i <= Times * 7 / 2)
		{
			th1 += (Pth2.Th2 - Pth4.Th2) / Times;
			th2 += (Pth4.Th2 - Pth1.Th2) / Times;
			th3 += (Pth2.Th1 - Pth4.Th1) / Times;
			th4 += (Pth4.Th1 - Pth1.Th1) / Times;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (Times * 7 / 2 < i && i <= Times * 4)
		{
			th1 += (Pth3.Th2 - Pth2.Th2) / Times * 2;
			th2 += (Pth4.Th2 - Pth1.Th2) / Times;
			th3 += (Pth3.Th1 - Pth2.Th1) / Times * 2;
			th4 += (Pth4.Th1 - Pth1.Th1) / Times;

			LGT_Motor_Group[1].Target_Angle = (float)th1;
			LGT_Motor_Group[2].Target_Angle = (float)th2;
			LGT_Motor_Group[3].Target_Angle = (float)th1;
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[1]);
			impedance_control(1, th3, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[2]);
			impedance_control(2, th4, 0, 0, k1p, k1d);
			osDelay(1);
			LGT_impedance_Control(LGT_Motor_Group[3]);
			impedance_control(3, th3, 0, 0, k1p, k1d);
			i++;
			osDelay(Dly);
		}
		else if (i > Times * 4)
		{
			i = Times + 1;
		}
		osDelay(1);
		unpackCanInfoFromMotor(LGT_rx_buffer, LGT_Motor_Group);
		DrPara = read_property(3, 38009, 0);
		User_UART_STLINK_printf("%f,%f \n", DrPara, LGT_Motor_Group[3].Output_Torque);

		osDelay(3);
	}
	/* USER CODE END DrLanTask */
}

/* USER CODE BEGIN Header_BMI088_INSTask */
/**
 * @brief Function implementing the BMI088_INS thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_BMI088_INSTask */
void BMI088_INSTask(void *argument)
{
	/* USER CODE BEGIN BMI088_INSTask */
	/* Infinite loop */
	// while (BMI088_init())
	// {
	// 	;
	// }
	// float DrPara;
	for (;;)
	{
		// BMI088_read(gyro, accel, &temp);
		// get_BMI088_gyro(gyro1);

		// unpackCanInfoFromMotor(LGT_rx_buffer, LGT_Motor_Group);
		// DrPara = read_property(3, 38009, 0);
		// User_UART_STLINK_printf("%f, %f, %f, %f, %f\n", DrPara, LGT_Motor_Group[3].Output_Torque, gyro1[0], gyro1[1], gyro1[2]);
		osDelay(1); // ����10ms��ִ��Ȩ
	}
	/* USER CODE END BMI088_INSTask */
}

/* USER CODE BEGIN Header_DebugTask */
/**
 * @brief Function implementing the USB_Debug thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_DebugTask */
void DebugTask(void *argument)
{

	/* USER CODE BEGIN DebugTask */
	// uint8_t data[30];
	// UART5_SendData(4, 6.28, 3.14, 10.0, 4.26, 2.13, 2.0);
	// UART5_SendData(5, 6.28, 3.14, 10.0, 4.26, 2.13, 2.0);
	// UART5_SendData(6, 6.28, 3.14, 10.0, 4.26, 2.13, 2.0);

	/* Infinite loop */
	for (;;)
	{
		// if (xQueueReceive(uartQueue, data, portMAX_DELAY) == pdPASS)
		// {
		// 	// ��ȡID��

		// 	// �������
		// 	memcpy(&id, &data[1], sizeof(uint8_t));
		// 	memcpy(&Dr_pos, &data[2], sizeof(float));
		// 	memcpy(&Dr_vel, &data[6], sizeof(float));
		// 	memcpy(&Dr_trf, &data[10], sizeof(float));
		// 	memcpy(&LGT_pos, &data[14], sizeof(float));
		// 	memcpy(&LGT_vel, &data[18], sizeof(float));
		// 	memcpy(&LGT_trf, &data[22], sizeof(float));

		// 	// ��������
		// 	// UART5_SendData(id, Dr_pos, Dr_vel, Dr_trf, LGT_pos, LGT_vel, LGT_trf);
		// }

		// ���� CPU ִ��Ȩ
		// vTaskDelay(pdMS_TO_TICKS(5)); // ��ʱ 5ms
		osDelay(1);
		/* USER CODE END DebugTask */
	}
}
/* USER CODE BEGIN Header_Empty_Task04 */
/**
 * @brief Function implementing the Empty_Task thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_Empty_Task04 */
void Empty_Task04(void *argument)
{
	/* USER CODE BEGIN Empty_Task04 */
	// /*���迹ģʽ*/
	// int i = 150;
	// float DrPara;
	// float d = -(PI / 6 * 7);
	// float e = -(PI / 6);
	// float f = -(PI / 6 * 7);
	// set_zero_position(4);
	// set_zero_position(5);
	// set_zero_position(6);
	// LGT_Motor_Enable(LGT_Motor_Group[4]);
	// LGT_Motor_Enable(LGT_Motor_Group[5]);
	// LGT_Motor_Enable(LGT_Motor_Group[6]);
	// LGT_Motor_Group[4].Target_Angle = -(float)(PI / 6.0 * 7);
	// LGT_Motor_Group[5].Target_Angle = -(float)(PI / 6.0);
	// LGT_Motor_Group[6].Target_Angle = -(float)(PI / 6.0 * 7);
	// osDelay(1);
	// LGT_impedance_Control(LGT_Motor_Group[4]);
	// osDelay(1);
	// LGT_impedance_Control(LGT_Motor_Group[5]);
	// osDelay(1);
	// LGT_impedance_Control(LGT_Motor_Group[6]);
	// osDelay(1);
	// impedance_control(6, 150, 0, 1, 5.0, 0.8);
	// osDelay(1);
	// impedance_control(4, 150, 0, 1, 5.0, 4.0);
	// osDelay(1);
	// impedance_control(5, -30, 0, 1, 5.0, 0.8);
	// osDelay(5000);
	/* Infinite loop */
	for (;;)
	{
		// i++;
		// d = d - PI / 177;
		// e = e - PI / 178;
		// f = f - PI / 177;
		// LGT_Motor_Group[4].Target_Angle = d;
		// LGT_Motor_Group[5].Target_Angle = e;
		// LGT_Motor_Group[6].Target_Angle = f;
		// LGT_impedance_Control(LGT_Motor_Group[4]);
		// osDelay(1);
		// LGT_impedance_Control(LGT_Motor_Group[5]);
		// osDelay(1);
		// LGT_impedance_Control(LGT_Motor_Group[6]);
		// osDelay(1);
		// impedance_control(4, i, 0, 1, 5.0, 4.0);
		// osDelay(1);
		// impedance_control(5, i - 180, 0, 1, 5.0, 0.8);
		osDelay(1);
		// impedance_control(6, i, 0, 1, 5.0, 0.8);
		// unpackCanInfoFromMotor(LGT_rx_buffer, LGT_Motor_Group);
		// DrPara = read_property(4, 38009, 0);
		// User_UART_STLINK_printf("%f, %f\n", DrPara, LGT_Motor_Group[4].Output_Torque);
		// osDelay(10);
	}
	/* USER CODE END Empty_Task04 */
}

/* USER CODE BEGIN Header_Ben_Leg_task */
/**
 * @brief Function implementing the Ben_Leg thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_Ben_Leg_task */
void Ben_Leg_task(void *argument)
{
	/* USER CODE BEGIN Ben_Leg_task */

	/* Infinite loop */
	for (;;)
	{
		osDelay(1);
	}
	/* USER CODE END Ben_Leg_task */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

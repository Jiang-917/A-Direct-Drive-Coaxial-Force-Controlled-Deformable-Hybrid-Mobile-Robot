#include "Control.h"
#include "LGT.h"

extern LGT_Motor_Handler LGT_Motor_Group[7];
extern uint8_t LGT_rx_buffer[8];

void WheelModeControl(char id, char mode, uint8_t velocity)
{
    if (mode == 1)
    {
        unpackCanInfoFromMotor(LGT_rx_buffer, LGT_Motor_Group);
        LGT_Motor_Enable(LGT_Motor_Group[id]);
        set_zero_position(id);
        LGT_Motor_Group[id].Target_Angle = 3.14 / 6;
        impedance_control(id, 30, 0, 1, 5.0, 0.8);

        osDelay(500);
    }
}

#include <stdio.h>
#include<malloc.h>
#include <stdlib.h>
#include <math.h>
#define M_PI 3.14159265358979323846

typedef struct {
    double r;
    double d1;
    double d2;
    double d3;
} ikine_dmp;

ikine_dmp* init_ikine_dmp(ikine_dmp* ikine,double r) {
    //��̬�����ڴ�
    ikine = (ikine_dmp*)malloc(sizeof(ikine_dmp));
    if (ikine) {
        ikine->r = r;
        printf("r:%lf ", ikine->r);
        ikine->d1 = sqrt(2) * ikine->r;
        printf("d1:%lf ", ikine->d1);
        ikine->d2 = sqrt(2 + sqrt(3)) * ikine->r;
        printf("d2:%lf ", ikine->d2);
        ikine->d3 = sqrt(3) * ikine->r;
        printf("d3:%lf\n", ikine->d3);
    }
    else {
        exit(-1);
    }
    return ikine;
}
double j_df11(double th1, double th2, double OA, double AC, double BC) {
    double df11;
    double term1 = 2 * OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))));
	double term2 = 2 * OA * sqrt(AC * AC + OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2)))));
	double term3=sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2))/(4*AC*OA*sin(th1/2-th2/2))))*
	(((OA*cos(th1/2-th2/2))/AC-(cos(th1/2-th2/2)*(AC*AC-BC*BC+4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)))/(8*AC*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)))/
	sqrt(1-pow((AC*AC-BC*BC+4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)),2)/(16*AC*AC*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2))) + 1/2);
	double term4=AC * AC + OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))));
	double term5=term3*term1/(2*pow(term4,3/2));
	double term6=sqrt(1 - pow((2*OA*OA - 2*AC*OA*cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))))),2)/(4*OA*OA*term4));

    df11= sin(th1-acos(term1/term2))*((AC*term3/sqrt(term4)-term5)/term6-1)*sqrt(term4)-(AC*OA*cos(th1 - acos(term1 /term2))*term3)/sqrt(term4);
    return df11;
}
double j_df12(double th1, double th2, double OA, double AC, double BC) {
    double df12;
    double term1 = 2 * OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))));
	double term2 = 2 * OA * sqrt(AC * AC + OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2)))));
	double term3=sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2))/(4*AC*OA*sin(th1/2-th2/2))))*
	(((OA*cos(th1/2-th2/2))/AC-(cos(th1/2-th2/2)*(AC*AC-BC*BC+4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)))/(8*AC*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)))/
	sqrt(1-pow((AC*AC-BC*BC+4*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2)),2)/(16*AC*AC*OA*OA*sin(th1/2-th2/2)*sin(th1/2-th2/2))) + 1/2);
	double term4=AC * AC + OA * OA - 2 * AC * OA * cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))));
	double term5=term3*term1/(2*pow(term4,3/2));
	double term6=sqrt(1 - pow((2*OA*OA - 2*AC*OA*cos(th2 / 2 - th1 / 2 + M_PI / 2 +acos((AC * AC - BC * BC + 4 * OA * OA * sin(th1 / 2 - th2 / 2) * sin(th1 / 2 - th2 / 2)) /(4 * AC * OA * sin(th1 / 2 - th2 / 2))))),2)/(4*OA*OA*term4));

    df12=AC*OA*cos(th1-acos(term1/term2))*term3/sqrt(term4)-(sin(th1-acos(term1/term2))*(AC*term3/sqrt(term4)-AC*term5)*sqrt(term4))/term6;
    return df12;
}
double j_df21(double th1, double th2, double OA, double AC, double BC) {
    double df21=- cos(th1 - acos((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))/(2*OA*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))))))*(((AC*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(8*AC*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(16*AC*AC*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))) + 1/2))/sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))) - (AC*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(8*AC*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(16*AC*AC*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))) + 1/2)*(2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))))/(2*((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))))))/sqrt((1 - ((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))*(2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))))/(4*OA*OA*(AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))))) - 1)*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))) - (AC*OA*sin(th1 - acos((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))/(2*OA*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2)))))))))*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(8*AC*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))*(AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))/(16*AC*AC*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2))))) + 1/2))/sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*(sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(4*AC*OA*sin(th1/2 - th2/2))))));
   
    return df21;
}
double j_df22(double th1, double th2, double OA, double AC, double BC) {
    double df22=(cos(th1 - acos((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))/(2*OA*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))))))*((AC*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(8*AC*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(16*AC*AC*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))) + 1/2))/sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))) - (AC*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(8*AC*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(16*AC*AC*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))) + 1/2)*(2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))))/(2*((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))))))*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))))/sqrt((1 - ((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))*(2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))))/(4*OA*OA*(AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))))) + (AC*OA*sin(th1 - acos((2*OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))/(2*OA*sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2)))))))))*sin(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))*(((OA*cos(th1/2 - th2/2))/AC - (cos(th1/2 - th2/2)*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(8*AC*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/sqrt((1 - ((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))*(AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))/(16*AC*AC*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2)))) + 1/2))/sqrt((AC*AC + OA*OA - 2*AC*OA*cos(th2/2 - th1/2 + M_PI/2 + acos((AC*AC - BC*BC + 4*OA*OA*sin(th1/2 - th2/2)*sin(th1/2 - th2/2))/(4*AC*OA*sin(th1/2 - th2/2))))));
    return df22;
}

int main() {
	double r = 1;
	ikine_dmp* ikine=NULL;
    ikine = init_ikine_dmp(ikine, r);
    // Assign values to th1, th2, OA, AC, BC
    double th1 = M_PI * 120 / 180.0, th2 = M_PI * 60 / 180.0;
    //OA--r,AC--d2,BC--d1
    double df11 = j_df11(th1, th2, r, ikine->d2, ikine->d1);
    double df12 = j_df12(th1, th2, r, ikine->d2, ikine->d1);
    double df21 = j_df21(th1, th2, r, ikine->d2, ikine->d1);
    double df22 = j_df22(th1, th2, r, ikine->d2, ikine->d1);
    printf("df11: %lf\n", df11);
    printf("df12: %lf\n", df12);
    printf("df21: %lf\n", df21);
    printf("df22: %lf\n", df22);

    return 0;
}
